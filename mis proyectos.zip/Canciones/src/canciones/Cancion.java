/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package canciones;

/**
 *
 * @author droid
 */
public class Cancion {
    //atributos de la clase cancion
    private String titulo;
    private String artista;
    private int duracion;
    private Boolean favorite;
    private boolean descargado;
    //contrructor con parametro
     public Cancion(String titulo, String artista, int duracion, Boolean favorite, boolean descargado) {
        this.titulo = titulo;
        this.artista = artista;
        this.duracion = duracion;
        this.favorite = favorite;
        this.descargado = descargado;
    }
     //contrucor sin parametro
    public Cancion(){
    
    }
  

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public void setFavorite(Boolean favorite) {
        this.favorite = favorite;
    }

    public void setDescargado(boolean descargado) {
        this.descargado = descargado;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getArtista() {
        return artista;
    }

    public int getDuracion() {
        return duracion;
    }

    public Boolean getFavorite() {
        return favorite;
    }

    public boolean isDescargado() {
        return descargado;
    }
    
    
    public void imprimirCancion() {
        int minuto = duracion / 60; //se divide la duracion para convertir en minutos
        int segundos = duracion % 60; //al usar % un mod  nos dara lo que sobra que seria los segundos de la duracion
        System.out.println("==============================");
        System.out.println("Título: " + this.titulo);
        System.out.println("Artista: " + this.artista);
        //if(segundos>10){
            //System.out.println("el tiempo de Duración es: " + minuto + ":" + segundos);//aqui  se mostrara los min duracion como ejemplo:3:21
        //}else {
        //System.out.println("el tiempo de Duración es: " + minuto + ":0" + segundos);
        //}
        String Duracion = minuto +":"+ (segundos < 10 ? "0" : "") + segundos;
         System.out.println(Duracion);
        System.out.println("==============================");}
        
                
    public void CalcularDuracion(){
 
        if(this.duracion>=300){
            System.out.println("la duracion es larga");
        }else{
            System.out.println("la duracion es larga");
        }
    }

public void adelantarCancion(int segundos){
    System.out.println("la cancion "+this.titulo+" se adelanto: "+segundos+"segundos");

}

    @Override
    public String toString() {
        return "Cancion{" + "titulo=" + titulo + ", artista=" + artista + ", duracion=" + duracion +"seg , favorite=" + favorite + ", descargado=" + descargado + '}';
    }

}

   
    //metodo tostring
 

        




