/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package canciones;
import java.util.Scanner;
/**
 *
 * @author droid
 */
public class Canciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        Scanner teclado=new Scanner(System.int);
//        
//        int numero=teclado.nextInt();
       
//        /switch se utiliza para hacer menu opciones largos
//        int numero=1;
//        String curso="";
//        switch (numero){
//            case 1 :
//                System.out.println("pimero basico");
//                break;
//            case 2 :
//                System.out.println("segundo basico");
//                break;
//            case 3 : 
//                System.out.println("tercero basico");
//                break;
//            default:
//                System.out.println("no existe el curso");
        
                
                
               
        
        
        
        
//        char generof'f';  
           
//
//        
        
        
      Cancion Cancion1=new Cancion("lagasolina","daddy yanke",190,true,true);
//        Cancion Cancion2=new Cancion();
//        
//        
//        
//        
//        
          Cancion1.imprimirCancion();
//        
          System.out.println(Cancion1.toString());
//        System.out.println(Cancion2.toString());
//        Cancion1.adelantarCancion(30);
//        
//        
//
//        
        
                
    }
    
}
