/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package listas;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author droid
 */
public class Listas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        List<String> listaNombres=new ArrayList();
        
        System.out.println(" la lista  de nombre"+listaNombres);
          
        listaNombres.add("luis");
        listaNombres.add("felipe");
        listaNombres.add("igancio");
        
       System.out.println("lista nombre"+listaNombres);
//        System.out.println("el tamaño de la lista es :"+listaNombres.size());=aqui dira el tamaño de la lista
//        
//        System.out.println("el nombre de indice 1 es :"+listaNombres.get(1));=al agregar un numero te dira que nombre esta en esa pocision
//        listaNombres.clear();//=esta funcion hace eliminar la lista
//        System.out.println("la lista es "+listaNombres);
        
//este FUNCION recorre la lista 
        
        for(int i=0;i<listaNombres.size();i++){
        
            System.out.println(listaNombres.get(i));
            

        
        
        }
  //este es otra funcion mas facil para recorrer LA LISTA
        for(String tmp:listaNombres){
            System.out.println(tmp);
        
        
        }
        
        
        
        
        
        
        
    }
    
}
