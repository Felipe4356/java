/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package verduleriaaa;

/**
 *
 * @author hansi
 */
public class Cliente {
    
    private String dv,Nombre,mail,Direccion;
    private int Run,Telefono;

    public Cliente(String dv, String Nombre, String mail, String Direccion, int Telefono,int Run) {
        this.dv = dv;
        this.Nombre = Nombre;
        this.mail = mail;
        this.Direccion = Direccion;
        this.Telefono = Telefono;
        this.Run= Run;
    }

    public Cliente() {
    }

    public String getDv() {
        return dv;
    }

    public void setDv(String dv) {
        this.dv = dv;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public int getTelefono() {
        return Telefono;
    }

    public void setTelefono(int Telefono) {
        this.Telefono = Telefono;
    }
    
    public int getRun(){
        return Run;
    }
    
    public void setRun(int Run){
        this.Run = Run ;
    }

    @Override
    public String toString() {
        return "Cliente{" + "dv=" + dv + ", Nombre=" + Nombre + ", mail=" + mail + ", Direccion=" + Direccion + ", Telefono=" + Telefono + '}';
    }
    
    
}
