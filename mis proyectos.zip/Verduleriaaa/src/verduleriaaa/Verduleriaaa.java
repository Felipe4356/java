/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package verduleriaaa;
import java.util.Scanner;
/**
 *
 * @author hansi
 */
public class Verduleriaaa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int opcion=0;
        int compra=0;
        int nrocliente=0;
        int contadorZanahoria=0;
        int contadorPepino=0;
        int contadorPiña=0;
        int contadorArandanos=0;
        int numBoleta=1;
        int Total=0;
        String nombre="";
        Producto producto1=new Producto(1000,890,"Verdura","Zanahoria","1000 Gr");
        Producto producto2=new Producto(1110,579,"Verdura","Pepino","1 Unidad");
        Producto producto3=new Producto(5000,894,"Fruta","Piña","1 Unidad");
        Producto producto4=new Producto(5005,1490,"Fruta","Arandanos","100 Gr");
        Cliente cliente1=new Cliente("0","Hans Mancilla","ha.mancilla@duocuc.cl","Av Transversal 3191",930907224,20933195);
        Cliente cliente2=new Cliente("3","Fernanda Mellado","fe.mellado@duocuc.cl","Los confines 4342",990307223,21253107);
        Scanner Teclado=new Scanner(System.in);
        System.out.println("Bienvenido al sistema compras 'El verdugo'");
        System.out.println("Ingrese su numero de cliente:");
        nrocliente=Teclado.nextInt();

        do{
            System.out.println("Eliga una opcion\n1.-Agregar un producto\n2.-Ver su boleta\n3.-Pagar\n4.-Salir del sistema");
            opcion=Teclado.nextInt();
            
            switch(opcion){
                case 1:
                    System.out.println("-----Lista de precios----");
                    System.out.println(producto1.getDescripcion());
                    System.out.println(producto2.getDescripcion());
                    System.out.println(producto3.getDescripcion());
                    System.out.println(producto4.getDescripcion());
                    compra=Teclado.nextInt();
                    if(compra==1){
                        System.out.println("Usted compró una "+producto1.getDescripcion());
                        System.out.println("$"+producto1.getPrecio());
                        contadorZanahoria++;
                    }else if(compra==2){
                        System.out.println("Usted compró un "+producto2.getDescripcion());
                        System.out.println("$"+producto2.getPrecio());
                        contadorPepino++;
                    }else if(compra==3){
                        System.out.println("Usted compró una "+producto3.getDescripcion());
                        System.out.println("$"+producto3.getPrecio());
                        contadorPiña++;
                    }else if(compra==4){
                        System.out.println("Usted compró 100gr de "+producto4.getDescripcion());
                        System.out.println("$"+producto4.getPrecio());
                        contadorArandanos++;
                    }else{
                        System.out.println("Valor incorrecto, intentelo nuevamente");
                    }
                    break;
                case 2:
                    System.out.println("---Boleta---");
                    System.out.println("Numero de boleta:"+numBoleta);
                    System.out.println("Fecha:02/09/2023 ");
                    if(nrocliente==1){
                        System.out.println("Cliente: "+cliente1.getNombre());
                    }else if(nrocliente==2){
                        System.out.println("Cliente: "+cliente2.getNombre());
                    }else{
                        System.out.println("Cliente equivocado");
                    }
                    Total=(contadorZanahoria*890)+(contadorPepino*579)+(contadorPiña*894)+(contadorArandanos*1490);
                    System.out.println("Total: "+Total);
                    System.out.println("---Productos--- ");
                    System.out.println("Zanahorias: "+contadorZanahoria);
                    System.out.println("Pepinos: "+contadorPepino);
                    System.out.println("Piñas: "+contadorPiña);
                    System.out.println("Arandanos: "+contadorArandanos);
                    numBoleta++;
                    break;
                
                case 3:
                
                case 4:
                    opcion=4;
            }
            
            
        }while(opcion!=4);
        
    }
    
}
