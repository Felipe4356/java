/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package verduleriaaa;

/**
 *
 * @author hansi
 */
public class Producto {
    private int Codigo,precio;
    private String Subcategoria,Descripcion,unidad;

    public Producto(int Codigo, int precio, String Subcategoria, String Descripcion, String unidad) {
        this.Codigo = Codigo;
        this.precio = precio;
        this.Subcategoria = Subcategoria;
        this.Descripcion = Descripcion;
        this.unidad= unidad;
    }

    public Producto() {
    }

    public int getCodigo() {
        return Codigo;
    }

    public void setCodigo(int Codigo) {
        this.Codigo = Codigo;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getUnidad() {
        return unidad;
    }

    public void setUnidad(String unidad) {
        this.unidad = unidad;
    }

    public String getSubcategoria() {
        return Subcategoria;
    }

    public void setSubcategoria(String Subcategoria) {
        this.Subcategoria = Subcategoria;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    @Override
    public String toString() {
         return "Producto{" + "Codigo=" + Codigo + ", precio=" + precio + ", Subcategoria=" + Subcategoria + ", Descripcion=" + Descripcion + ", unidad=" + unidad + '}';
}
    }
    
