/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package figuras;

/**
 *
 * @author droid
 */
public abstract class figura {
    protected String nombre ;
    int lado1;
    int lado2;

    public figura(String nombre, int lado1, int lado2) {
        this.nombre = nombre;
        this.lado1 = lado1;
        this.lado2 = lado2;
    }

    public figura() {
    }
    

    public String getNombre() {
        return nombre;
    }

    public int getLado1() {
        return lado1;
    }

    public int getLado2() {
        return lado2;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setLado1(int lado1) {
        this.lado1 = lado1;
    }

    public void setLado2(int lado2) {
        this.lado2 = lado2;
    }

    @Override
    public String toString() {
        return "figura_geometrica{" + "nombre=" + nombre + ", lado1=" + lado1 + ", lado2=" + lado2 + '}';
    }
    

    

    public abstract int calcularArea();
    
    public abstract int calcularPerimetro();
  public abstract int dibujarfigura();
  
  
  
  public final void mostrardatos(){
            System.out.println(" area"+calcularArea());
            System.out.println("perimetro:"+calcularPerimetro());
            
            
            


}
        
    
    
    
    

}
    





    

