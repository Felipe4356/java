/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package microempresa;

/**
 *
 * @author droid
 */
public class Producto {
    //estos son los atributos
    private int codigo;
    private String subcategoria;
    private String descripcion;
    private int precio;
    private String gramos;

    public Producto(int codigo, String subcategoria, String descripcion, int precio, String gramos) {
        this.codigo = codigo;
        this.subcategoria = subcategoria;
        this.descripcion = descripcion;
        this.precio = precio;
        this.gramos = gramos;
    }

  
    public Producto() {
    }

    public int getCodigo() {
        return codigo;
    }

    public String getSubcategoria() {
        return subcategoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getPrecio() {
        return precio;
    }

    public String getGramos() {
        return gramos;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setSubcategoria(String subcategoria) {
        this.subcategoria = subcategoria;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public void setGramos(String gramos) {
        this.gramos = gramos;
    }

    @Override
    public String toString() {
        return "Producto{" + "codigo=" + codigo + ", subcategoria=" + subcategoria + ", descripcion=" + descripcion + ", precio=" + precio + ", gramos=" + gramos + '}';
    }
    
   
    
    
}
