/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package microempresa;

/**
 *
 * @author droid
 */
public class Cliente {
    private String nombre;
    private String mail;
    private String direccion;
    private int rut;
    private String dv;
    private int telefono;

    public Cliente(String nombre, String mail, String direccion, int rut, String dv, int telefono) {
        this.nombre = nombre;
        this.mail = mail;
        this.direccion = direccion;
        this.rut = rut;
        this.dv = dv;
        this.telefono = telefono;
    }

    public Cliente() {
    }

    public String getNombre() {
        return nombre;
    }

    public String getMail() {
        return mail;
    }

    public String getDireccion() {
        return direccion;
    }

    public int getRut() {
        return rut;
    }

    public String getDv() {
        return dv;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setRut(int rut) {
        this.rut = rut;
    }

    public void setDv(String dv) {
        this.dv = dv;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "Cliente{" + "nombre=" + nombre + ", mail=" + mail + ", direccion=" + direccion + ", rut=" + rut + ", dv=" + dv + ", telefono=" + telefono + '}';
    }

   
}
    
    
    

