/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package microempresa;

import java.util.Scanner;

/**
 *
 * @author droid
 */
public class Microempresa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {// TODO code application logic here
        int total=0;
        int czanahoria=0;
        int cpepino=0;
        int carandano=0;
        Cliente Cliente1 = new Cliente("pepito", "pepito@gmail.com", "alto de alcer", 2123321, "k", 52525);
        Cliente Cliente2 = new Cliente();

        Producto zanahoria = new Producto(1000, "verdura", "zanahoria", 898, null);
        Producto pepino = new Producto(1100, "verdura", "pepino", 578, null);
        Producto arandano = new Producto(5000, "fruta", "arandano", 1400, null);
        int opcion =0;
        int opcion2=0 ;
        Scanner teclado = new Scanner(System.in);
        
        do {
            
            System.out.println("====menu====");
            System.out.println("1.agregar producto");
            System.out.println("2.ver detalle del pedido");
            System.out.println("3.añadir cliente");
            System.out.println("4.salir");
            opcion=teclado.nextInt();
            
                
            
            switch(opcion){
                case 1:
                    System.out.println("listado de producto");
                    System.out.println("1-"+pepino.getDescripcion());
                    System.out.println("2-"+arandano.getDescripcion());
                    System.out.println("3-"+zanahoria.getDescripcion());
                    opcion2=teclado.nextInt();
                   
                    if(opcion2==1){
                        cpepino++;
                        System.out.println("ingresaste pepino");
                    }else if (opcion2==2){
                    carandano++;
                        System.out.println(" ingresaste arandano");           
                    }else if (opcion2==3){
                    czanahoria++;
                    System.out.println("ingresaste zanahoria");}
                    else{
                        System.out.println("no existe ese producto");
                    }
                            
                    break;
                case 2:
                    System.out.println("Detalle del pedido");
                    System.out.println("Nombre del Cliente: " + Cliente1.getNombre());
                    System.out.println("Direccion: " + Cliente1.getDireccion());
                    System.out.println("Telefono: " + Cliente1.getTelefono());
                    System.out.println(czanahoria + " " + zanahoria.getDescripcion() + " Precio: " + (czanahoria * zanahoria.getPrecio()));
                    System.out.println(cpepino + " " + pepino.getDescripcion() + " Precio: " + (cpepino * pepino.getPrecio()));
                    System.out.println(carandano+" "+arandano.getDescripcion()+"precio: "+(carandano*arandano.getPrecio()));
                  
             
                    break;
                case 3:
                    System.out.println("ingrese nombre");
                    String nombre = teclado.next();
                    Cliente2.setNombre(nombre);
                    System.out.println("ingrese imail");
                    String mail = teclado.next();
                    Cliente2.setMail(mail);
                    System.out.println("ingrese su direccion");
                    String direccion= teclado.next();
                    Cliente2.setDireccion(direccion);
                    System.out.println("ingrese su rut");
                    int run = teclado.nextInt();
                    Cliente2.setRut(run);
                    System.out.println("ingrese dv");
                    String dv=teclado.next();
                    Cliente2.setDv(dv);
                    System.out.println("ingresa telefono");
                    int telefono=teclado.nextInt();
                    Cliente2.setTelefono(telefono);
                    System.out.println(Cliente2);
                    break;
                    
                 
                    
                            
                    
                    
                case 4:
                default:
                    System.out.println("Default");
            }   
                        
        
        
        }while(opcion!=4);   
        System.out.println("saliste");
                   
        
            
                    
                    
                    
        
    }
}
            
        
            
           

      
    
 
    
