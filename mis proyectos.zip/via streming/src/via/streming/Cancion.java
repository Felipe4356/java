/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package via.streming;

/**
 *
 * @author droid
 */
public class Cancion {
    String titulo;
    String artista;
    int duracion;
    Boolean favorite;
    
    public Cancion(String titulo, String artista, int duracion, Boolean favorite) {
        this.titulo = titulo;
        this.artista = artista;
        this.duracion = duracion;
         this.favorite = favorite;
    }
  

 
 
   

    @Override
    public String toString() {
        return "Cancion{" + "titulo=" + titulo + ", artista=" + artista + ", duracion=" + duracion + ", favorite=" + favorite + '}';
    }

    public void reproductor(){
    int minuto=duracion/60;
    int segundos=duracion%60;
    System.out.println("titulo"+this.titulo);
    System.out.println("autor"+this.artista);
    System.out.println("duracion "+minuto+":"+segundos);
    System.out.println("favorite"+this.favorite);
    
   }
    public void reproducir (){
        System.out.println(titulo);
    
    }
    
    }
   

