/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gifcard;

        

/**
 *
 * @author droid
 */
public class Gifcard {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    Usuario Usuario1=new Usuario(12189443,"5",Juan); 
    Usuario Usuario2=new Usuario(18112345,"k","Rosita morales");
    
   
}
