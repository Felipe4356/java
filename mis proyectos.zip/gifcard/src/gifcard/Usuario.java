/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gifcard;

import java.text.DecimalFormat;

/**
 *
 * @author droid
 */
public class Usuario {

    private int rut;
    private String dv;
    private String nombre;
    private  targeta targeta;

    public Usuario() {
    }

    public Usuario(int rut, String dv, String nombre) {
        this.rut = rut;
        this.dv = dv;
        this.nombre = nombre;
    }

    public void setRut(int rut) {
        this.rut = rut;
    }

    public void setDv(String dv) {
        this.dv = dv;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getRut() {
        return rut;
    }

    public String getDv() {
        return dv;
    }

    public String getNombre() {
        return nombre;
    }

    

            
}
            

                        
                       


