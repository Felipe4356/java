/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gifcard;

/**
 *
 * @author droid
 */
public class Targeta {

    private int codigo;
    private int clave;
    private int monto;
    private String vigencia;
    private String trabajador1;

    public Targeta() {
    }

    public Targeta(int codigo, int clave, int monto, String vigencia, String trabajador1) {
        this.codigo = codigo;
        this.clave = clave;
        this.monto = monto;
        this.vigencia = vigencia;
        this.trabajador1 = trabajador1;
    }

}
