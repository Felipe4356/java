/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package evaluacion1;

/**
 *
 * @author Y409-PCXX
 */
public class Tarjeta {
    //Atributos
    private int tarjetaID;
    private String nombreCliente;
    private int cupo;
    //Constructores 
    public Tarjeta(int tarjetaID, String nombreCliente, int cupo) {
        this.tarjetaID = tarjetaID;
        this.nombreCliente = nombreCliente;
        this.cupo = cupo;
    }
    //Constructor Vacio
    public Tarjeta() {
    }
    //Getter (Accesadores)
    public int getTarjetaID() {
        return tarjetaID;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public int getCupo() {
        return cupo;
    }
    //Mutadores
    public void setTarjetaID(int tarjetaID) {
        this.tarjetaID = tarjetaID;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public void setCupo(int cupo) {
        this.cupo = cupo;
    }

    @Override
    public String toString() {
        return "Tarjeta{" + "tarjetaID=" + tarjetaID + ", nombreCliente=" + nombreCliente + ", cupo=" + cupo + '}';
    }
    
    public String plan(){
        String plan = null;
        if (cupo<250000){
            plan = "Tarjeta Basica, Usted es un cliente Basico";
        } else if (cupo>=250000 && cupo <=500000){
            plan = "Tarjeta Premium, Usted es un cliente Premium";
        } else if (cupo>500000){
            plan = "Tarjeta Gold, Usted es un cliente Gold";
        }
        return plan;
    }
    public int comprarCupo(int compra){
        if (compra>cupo){
            System.out.println("Usted no puede comprar esto, cupo insuficiente");
        } else{
            cupo = cupo - compra;
            System.out.println("--Boleta---");
            System.out.println("Producto Ingresado de valor: " + compra);
            System.out.println("---------------------------------");
            System.out.println("Total: " + compra);
            System.out.println("Cupo Restante: "+ cupo);
            System.out.println("Nombre: "+ this.nombreCliente);
            System.out.println("Tarjeta: "+ this.tarjetaID);
            System.out.println("-------------------------------");
            System.out.println("Compra Realizada con exito, su compra fue "+ compra + " el cupo disponible actual "+ cupo);
        }
        return cupo;
    }
    public String descuentoSemanal(int dia){
        String descuento = null;
        if (1 == dia && cupo < 250000){
            descuento = "Tiene un descuento del 10% en su compra";
        } else if (3 == dia && (cupo >=250000 && cupo<=500000)){
            descuento = "Tiene un descuento del 15% en su compra";
        } else if (5 == dia && cupo >500000){
            descuento = "Tiene un descuento del 20% en su compra";
        } else {
            descuento ="No tienes descuento";
        }
        return descuento;
    }
}
    
