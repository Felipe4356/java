/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package evaluacion1;

import java.util.Scanner;

/**
 *
 * @author Y409-PCXX
 */
public class Evaluacion1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Tarjeta tarjeta1 = new Tarjeta(3241, "Alvaro Diaz", 2500000); //Objeto con valores
        Tarjeta tarjeta2 = new Tarjeta();//Objeto Vacio
        Scanner teclado = new Scanner(System.in); //Clase Escaner para meter datos por teclado 
        System.out.println("Antes de entrar al sistema ingrese sus datos para la Segunda Tarjeta"); //Pidiendo datos
        
        System.out.println("Id de su tarjeta: "); //Id
        int idTarjeta = teclado.nextInt(); //Variablae la cual se va llenar la clase
        tarjeta2.setTarjetaID(idTarjeta); //Mutar clase vacia con datos
        
        System.out.println("Su nombre: "); //Nombre
        String nombre = teclado.next(); //Variablae la cual se va llenar la clase
        tarjeta2.setNombreCliente(nombre); //Mutar clase vacia con datos
        
        System.out.println("Ingrese el cupo disponible: "); //Cupo
        int cupoD = teclado.nextInt(); //Variablae la cual se va llenar la clase
        tarjeta2.setCupo(cupoD); //Mutar clase vacia con datos
        
        

        int opcion = 0;
        do {
        System.out.println("----Menu-----");
        System.out.println("1)Que tipo de cliente eres");
        System.out.println("2)Calcular Compra");
        System.out.println("3)Descuento");
        System.out.println("4)Salir");
        opcion = teclado.nextInt();
        switch(opcion){
            case 1: // Opcion 1 Tipo cliente
                System.out.println("Verificando...");
                System.out.println("Cliente 1: " + tarjeta1.getNombreCliente());
                System.out.println(tarjeta1.plan());
                System.out.println("-------");
                System.out.println("Cliente 2: " + tarjeta2.getNombreCliente());
                System.out.println(tarjeta2.plan());
                break;
            case 2: /// Opcion 2 Calcular Compra
                System.out.println("Ingrese el valor de la compra ");
                int compra = teclado.nextInt();
                System.out.println("Cliente 1: " + tarjeta1.getNombreCliente());
                tarjeta1.comprarCupo(compra);
                System.out.println("-------");
                System.out.println("Cliente 2: " + tarjeta2.getNombreCliente());
                tarjeta2.comprarCupo(compra);
                break;
            case 3: // Opcion 3 Descuento
                System.out.println("Ingrese el dia de hoy(Lunes(1)/Martes(2)/Miercoles(3)/Jueves(4)/Viernes(5)/Sabado(6)/Domingo(7))");
                int dia = teclado.nextInt();
                System.out.println("Cliente 1: " + tarjeta1.getNombreCliente());
                System.out.println(tarjeta1.descuentoSemanal(dia));
                System.out.println("-------");
                System.out.println("Cliente 2: " + tarjeta2.getNombreCliente());
                System.out.println(tarjeta2.descuentoSemanal(dia));
                break;
            case 4:// Opcion 4 Salir
                System.out.println("Saliendo...");
                break;
            default: //Salida por default si ingresa algo no valido.
                System.out.println("Opcion invalida.");
        }   
        } while (opcion != 4);
        System.out.println("Salio del sistema gracias por usar, Nicolas Hernandez Seccion 001"); // Mensaje Salida
    }
    
}
