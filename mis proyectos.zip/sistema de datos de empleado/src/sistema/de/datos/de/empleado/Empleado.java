/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.de.datos.de.empleado;

/**
 *
 * @author droid
 */
public class Empleado {
    private String rut;
    private String nombre;
    private String sexoEmpleado;
    private int añoServicio;
    private int edadEmpleado;
    private Puesto puestoEmpleado;

    public Empleado() {
    }

    public Empleado(String rut, String nombre, String sexoEmpleado, int añoServicio, int edadEmpleado, Puesto puestoEmpleado) {
        this.rut = rut;
        this.nombre = nombre;
        this.sexoEmpleado = sexoEmpleado;
        this.añoServicio = añoServicio;
        this.edadEmpleado = edadEmpleado;
        this.puestoEmpleado = puestoEmpleado;
    }

    public String getRut() {
        return rut;
    }

    public String getNombre() {
        return nombre;
    }

    public String getSexoEmpleado() {
        return sexoEmpleado;
    }

    public int getAñoServicio() {
        return añoServicio;
    }

    public int getEdadEmpleado() {
        return edadEmpleado;
    }

    public Puesto getPuestoEmpleado() {
        return puestoEmpleado;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setSexoEmpleado(String sexoEmpleado) {
        this.sexoEmpleado = sexoEmpleado;
    }

    public void setAñoServicio(int añoServicio) {
        this.añoServicio = añoServicio;
    }

    public void setEdadEmpleado(int edadEmpleado) {
        this.edadEmpleado = edadEmpleado;
    }

    public void setPuestoEmpleado(Puesto puestoEmpleado) {
        this.puestoEmpleado = puestoEmpleado;
    }

    @Override
    public String toString() {
        return "Empleado{" + "rut=" + rut + ", nombre=" + nombre + ", sexoEmpleado=" + sexoEmpleado + ", a\u00f1oServicio=" + añoServicio + ", edadEmpleado=" + edadEmpleado + ", puestoEmpleado=" + puestoEmpleado + '}';
    }
  
}
