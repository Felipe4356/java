/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.de.datos.de.empleado;

import java.util.ArrayList;

/**
 *
 * @author droid
 */
public class Empresa {

    private ArrayList<Empleado> listaEmpleado;

    public Empresa() {
        listaEmpleado = new ArrayList<Empleado>();
    }

    public boolean agregar(Empleado emple) {
        return listaEmpleado.add(emple);//esta funcion agregara al empleado

    }

    public boolean BuscarEmpleado(String rut){
    for (Empleado emple:listaEmpleado){
    if (emple.getRut().equals(rut));
    return true;
    }
        return false;
    
    }
    

    
   
    
    public void listaEnpleado() {
        for (Empleado emple : this.listaEmpleado) {
            System.out.println(emple.toString());
            

        }
    }

    public boolean eliminarEmpleado(String rut) {

        for (Empleado emple : this.listaEmpleado) {
            if(emple.getRut().equals(emple));
            listaEmpleado.remove(emple);
            return true;
                
            }
        return false;
        }
       
        
    }
    


