/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistema.de.datos.de.empleado;

import java.awt.BorderLayout;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author droid
 */
public class SistemaDeDatosDeEmpleado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Puesto Puesto1 = new Puesto(001, "administracion");
        Puesto Puesto2 = new Puesto(002, "informatica");
        Puesto Puesto3 = new Puesto(003 ,"info");
        Puesto Puesto4 = new Puesto(004, "analista");
        Empleado empleado1 = new Empleado("223233232k", "esteban parra", "m", 2023, 20, Puesto1);
        Empleado empleado2 = new Empleado("21347880-K", "Felipe Godoy", "M", 2011, 20, Puesto2);
        Empleado empleado3 = new Empleado ("21234243","hyan perez","m",2012,21,Puesto3);
        Empleado empleado4 = new Empleado();
        Empresa empresa = new Empresa();
        Scanner teclado = new Scanner(System.in);
      
      
       
       
            empresa.agregar(empleado1);
            empresa.agregar(empleado2);
            
           empresa.listaEnpleado();
           
//           if(empresa.eliminarEmpleado("21234243")){ 
//           System.out.println("se elimino empleado");
//           empresa.listaEnpleado();
//           
//            }else {
//            System.out.println("no se elimino ");
//            empresa.listaEnpleado();
//           }
           
        if(empresa.BuscarEmpleado("21347880-k")==false){
            System.out.println("empleado existente");
        } else{
            
            System.out.println(" se agrego empleado "+empleado3.getNombre());
            
        }
           
           
           
           
           
           
           
           
           
           
    }
  
}   
    

