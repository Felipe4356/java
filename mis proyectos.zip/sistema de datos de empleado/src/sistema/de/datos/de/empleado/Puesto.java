/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.de.datos.de.empleado;



/**
 *
 * @author droid
 */
public class Puesto {
    private int coidgo;
    private String nombre;

    public Puesto(int coidgo, String nombre) {
        this.coidgo = coidgo;
        this.nombre = nombre;
    }

    public Puesto() {
    }

    
    public int getCoidgo() {
        return coidgo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setCoidgo(int coidgo) {
        this.coidgo = coidgo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Puesto{" + "coidgo=" + coidgo + ", nombre=" + nombre + '}';
    }

   
   
    
}
