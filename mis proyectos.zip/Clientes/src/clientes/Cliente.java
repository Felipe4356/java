/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clientes;

/**
 *
 * @author droid
 */
public class Cliente {
    String nombre;
    String apellido;
    int edad;
    Targeta targeta;

    public Cliente() {
    }

    public Cliente(String nombre, String apellido, int edad, Targeta targeta) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.targeta = targeta;
        
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setTargeta(Targeta targeta) {
        this.targeta = targeta;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getEdad() {
        return edad;
    }

    public Targeta getTargeta() {
        return targeta;
    }

    public void mostrardatos(){
    Sytem
    
    
    }
    
    
    
    @Override
    public String toString() {
        return "Cliente{" + "nombre=" + nombre + ", apellido=" + apellido + ", edad=" + edad + ", targeta=" + targeta + '}';
    }
    
}
