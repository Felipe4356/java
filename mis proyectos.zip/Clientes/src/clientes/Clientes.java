/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clientes;
import java.util.Scanner;
import javax.sound.midi.Soundbank;
/**
 *
 * @author droid
 */
public class Clientes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Cliente cliente1=new Cliente("jaunito","montes",18,target2);
        Targeta Targeta2=new Targeta(111,11,500,5000,true);
        Cliente1.setNombre("pedro");
        Cliente1.setApellido("monte");
        
        int opcion=0;
        Scanner leer=new Scanner(System.in);
        
        do{ System.out.println("menu");
            System.out.println("1.agregar saldo");
            System.out.println("2.retirar saldo");
            System.out.println("3.");
            System.out.println("4.");
            opcion =leer.nextInt();
            switch(opcion){
                case 1:
                    System.out.println("cuanto va agegar");
                    
                    
                    
                    
                    break;
;
            
            
            
            }
        }
        
    }
    
}
