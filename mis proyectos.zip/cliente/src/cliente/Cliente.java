/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cliente;

import java.util.Scanner;

/**
 *
 * @author droid
 */
public class Cliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Trabajador Trabajador1 = new Trabajador(12189443, "-5", "Juan Perez");
        Trabajador Trabajador2 = new Trabajador(1812345, "-k", "Rosita Morales");

        Tarjeta Tarjeta1 = new Tarjeta(601874130, 1218, 35000, "30 de octubre 2020", "trabajador1");
        Tarjeta Tarjeta2 = new Tarjeta(7149741, 1811, 5500, "30 de octubre 2021", "trabajador2");
        int opcion = 0;
        Scanner leer = new Scanner(System.in);
        do {
            
            System.out.println("=============menu============");
            System.out.println("1.registrarse con rut clave");
            System.out.println("2.validar clave");
            System.out.println("3.carrito");
            System.out.println("4.monto restante");
            System.out.println("salir");
            opcion = leer.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("dar codigo alaetaorio 16 digto");
                    break;
                case 2:
                    System.out.println("usted ingreso para validar clave");
                    
                    break;
                case 3:
                    System.out.println("compra");
                    break;
                case 4:
                    System.out.println("monto restante");
                    break;
                case 5:
                    System.out.println("saliendo.....");
                    break;
                default:
                    System.out.println("opcion no existe");
            }
        }while(opcion!=5);
    }
}