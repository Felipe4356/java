/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cliente;

/**
 *
 * @author droid
 */
public class Trabajador {

    private int run;
    private String dv;
    private String nombre;

    public Trabajador() {
    }

    public Trabajador(int run, String dv, String nombre) {
        this.run = run;
        this.dv = dv;
        this.nombre = nombre;
    }

    public void setRun(int run) {
        this.run = run;
    }

    public void setDv(String dv) {
        this.dv = dv;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getRun() {
        return run;
    }

    public String getDv() {
        return dv;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "Trabajador{" + "run=" + run + ", dv=" + dv + ", nombre=" + nombre + '}';
    }
    

    
    

}
