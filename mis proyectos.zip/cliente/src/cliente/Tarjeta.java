/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cliente;

/**
 *
 * @author droid
 */
public class Tarjeta {
    private int codigo;
    private int clave;
    private double monto;
    private String vigencia;
    private String Trabajador1;
    

    public Tarjeta() {
    }

    public Tarjeta(int codigo, int clave, double monto, String vigencia, String Trabajador1) {
        this.codigo = codigo;
        this.clave = clave;
        this.monto = monto;
        this.vigencia = vigencia;
        this.Trabajador1 = Trabajador1;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setClave(int clave) {
        this.clave = clave;
    }

    public void setMonto(int monto) {
        this.monto = monto;
    }

    public void setVigencia(String vigencia) {
        this.vigencia = vigencia;
    }

    public void setTrabajador1(String Trabajador1) {
        this.Trabajador1 = Trabajador1;
    }

    public int getCodigo() {
        return codigo;
    }

    public int getClave() {
        return clave;
    }

    public double getMonto() {
        return monto;
    }

    public String getVigencia() {
        return vigencia;
    }

    public String getTrabajador1() {
        return Trabajador1;
    }
   

    
   
    
    
    

 


   
    @Override
    public String toString() {
        return "Tarjeta{" + "codigo=" + codigo + ", clave=" + clave + ", monto=" + monto + ", vigencia=" + vigencia + ", Trabajador1=" + Trabajador1 + '}';
    }
    
            
    
}
