/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actividad.en.clases;

import java.util.Scanner;

/**
 *
 * @author droid
 */
public class ActividadEnClases {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
////        boolean flag = true;
//        Scanner teclado = new Scanner(System.in);
//        int opcion;
//        int contPeperoni=0,contVegetariana=0,contItaliana=0;
//        do {
//
//            System.out.println("-------menu de pizza-------");
//            System.out.println("1.pizzapeeroni");
//            System.out.println("2.pizza vegetariana");
//            System.out.println("3.pizza italina");
//            System.out.println("4");
//            System.out.println("5.");
//            opcion = teclado.nextInt();
//            switch (opcion) {
//                case 1:
//                    System.out.println("usted eligio peperoni");
//                    contPeperoni++;
//                    break;
//                case 2:
//                    System.out.println("usted eligio vegetariana ");
//                    contVegetariana++;
//                    
//                    break;
//         
//                case 3:
//                    System.out.println("usted iligio italina");
//                    contItaliana++;
//                    break;
//                case 4:
//                    System.out.println("pizza peperoni"+contPeroni);
//                    System.out.println("");
//                 
//                    
//                default:
//                    System.out.println("esta incorrecto");
//                    break;
//
//            }
//        } while (opcion != 3);
//    }
//      int
    
        
      
 
    
    
    