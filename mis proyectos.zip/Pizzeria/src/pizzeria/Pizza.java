/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pizzeria;

/**
 *
 * @author Y409-PCXX
 */
public class Pizza {
    
    String nombre;
    String tamano;
    String masa;
    //metodo constructor

    public Pizza(String nombre, String tamano, String masa) {
        this.nombre = nombre; 
        this.tamano = tamano;
        this.masa = masa;
    }
// metdodo contructor vacio
    public Pizza() {
    }
    
    
//metodo mutadores(permiten modificar o agregar datos)
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setTamano(String tamano) {
        this.tamano = tamano;
    }

    public void setMasa(String masa) {
        this.masa = masa;
    }

    //para agregar
    public String getNombre() {
        return nombre;
    }

    public String getTamano() {
        return tamano;
    }

    public String getMasa() {
        return masa;
    }

    @Override//sobrecribe un metodo
    public String toString() {
        return "Pizza{" + "nombre=" + nombre + ", tamano=" + tamano + ", masa=" + masa + '}';
    }
    
    
    
    //metodo customer(lo que el cliente solicita)
    public void preparar(){
         System.out.println("============================================");
       System.out.println("la pizza esta "+this.nombre+" preparando... tamano : "+this.tamano+ " masa: "+this.masa+"");
        
        
    }
    //metodo customer(lo que el cliente solicita)
    public void calentar(){
        System.out.println("============================================");
        System.out.println("la pizza "+this.nombre+  " esta calentando....");
    
    }
        
        
    
}
