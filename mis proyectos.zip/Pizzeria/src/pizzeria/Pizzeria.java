/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pizzeria;

/**
 *
 * @author Y409-PCXX
 */
public class Pizzeria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //todo codigo va aqui dentro
        
        Pizza Pizza1=new Pizza("peperoni","familiar","grande");
        Pizza Pizza2=new Pizza("vegetariana","mediana","delgada");
        Pizza Pizza3=new Pizza();
                
//        Pizza1.preparar();
//                
//        
//        Pizza2.preparar();
//        
//        Pizza3.setNombre("italiana");
//        
//        Pizza1.calentar();
//        
//        Pizza2.calentar();
//        
//        Pizza3.calentar();
//        
//        System.out.println(Pizza2.getNombre());
        Pizza3.setNombre("queso champiñon");
        Pizza3.setTamano("gruesa");
        Pizza3.setMasa("grande");
        System.out.println(Pizza1.toString());
        System.out.println(Pizza2.toString());
        System.out.println(Pizza3.toString());     
        
     
        
        
        
        
        
     
    }
    
}
