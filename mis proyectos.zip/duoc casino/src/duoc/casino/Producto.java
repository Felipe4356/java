/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package duoc.casino;

/**
 *
 * @author droid
 */
public class Producto {
    private int id;
    private String nombre_producto;
    private int precio;
    private int cantidad_producto;

    public Producto(int id, String nombre_producto, int precio, int cantidad_producto) {
        this.id = id;
        this.nombre_producto = nombre_producto;
        this.precio = precio;
        this.cantidad_producto = cantidad_producto;
    }

    public Producto() {
    }

    public int getId() {
        return id;
    }

    public String getNombre_producto() {
        return nombre_producto;
    }

    public int getPrecio() {
        return precio;
    }

    public int getCantidad_producto() {
        return cantidad_producto;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre_producto) {
        this.nombre_producto = nombre_producto;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public void setCantidad_producto(int cantidad_producto) {
        this.cantidad_producto = cantidad_producto;
    }

    
    public void Mostrar( ){
        
        
       int compra=this.precio*this.cantidad_producto;
       int  compraConiva=(int) ( (int) (compra  )*0.19  );
       int totalCompra=compra+compraConiva;
        System.out.println("id producto : "+this.id+"");
        System.out.println("nombre producto: "+this.nombre_producto);
        System.out.println("precio: "+  this.precio   );
        System.out.println("total iva: "+compraConiva); 
        System.out.println("total compra: "+totalCompra);
      
    }
    
    
    public int descuento(String horario){
    
    if( horario=="diurno"){
        return 10;
    
    }else if (horario=="verpetino"){
   
        return 15;
    }else{
        return 0;
    } 
           
    
    
    
    
    }
    @Override
    public String toString() {
        return "Producto{" + "id=" + id + ", nombre=" + nombre_producto + ", precio=" + precio + ", cantidad_producto=" + cantidad_producto + '}';
    }
          
    
}
