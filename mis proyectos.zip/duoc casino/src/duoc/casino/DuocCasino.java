/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package duoc.casino;

/**
 *
 * @author droid
 */
public class DuocCasino {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Producto producto1=new Producto(1,"papaslife",3600,4);
        producto1.Mostrar();
        System.out.println("el descuento es: "+producto1.descuento("diurno")+"%");
    }
    
}