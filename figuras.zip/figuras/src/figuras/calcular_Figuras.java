/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package figuras;

/**
 *
 * @author droid
 */
public class calcular_Figuras {

    /**
     * @param args the command line arguments
     */
    
      public static void main(String[] args) {
    figura Cuadrado1 = new Cuadrado("cuadrado", 5, 6);
    figura Rectangulo = new Rectangulo("rectangulo", 5, 10);

  Cuadrado1.mostrardatos();
  Cuadrado1.dibujarfigura();
          System.out.println("");
    Rectangulo.mostrardatos();
    Rectangulo.dibujarfigura();
  
    
}
}
