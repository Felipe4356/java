/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package figuras;

/**
 *
 * @author droid
 */
public class Rectangulo extends figura {

    public Rectangulo(String nombre, int lado1, int lado2) {
        super(nombre, lado1, lado2);
    }

    public Rectangulo() {
    }

    
    @Override
    public int calcularArea() {
    int calcular= lado1 *lado2;
        
                
        return calcular;
    }

    @Override
    public int calcularPerimetro() {
       int calcular2= lado1*2+lado2*2;
       
        return calcular2;
       
    }

    @Override
    public int dibujarfigura() {
        
        for (int i = 0; i < lado1; i++) {
            for (int j = 0; j < lado2; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }
        return 0;
    }
}
    


  
 



