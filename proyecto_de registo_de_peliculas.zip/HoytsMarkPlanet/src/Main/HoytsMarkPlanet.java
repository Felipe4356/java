/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

import controlador.BD;
import vistas.*;

/**
 *
 * @author droid
 */
public class HoytsMarkPlanet {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        BD conect=new BD();
        
        conect.conexionBD();
        login_m inicio =new login_m();
        
        inicio.setVisible(true);
    }
    
    
}
