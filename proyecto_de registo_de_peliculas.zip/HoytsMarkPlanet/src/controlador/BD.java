    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.sql.PreparedStatement;
/**
 *
 * @author droid
 */
public class BD {
     public Connection conexionBD(){
     String url="jdbc:mysql://localhost:3306/movieBD";
    String usuario="root";
    String contraseña="Felipe432156";       
        
    
    try{
            
        
            Connection conexion=DriverManager.getConnection(url, usuario, contraseña);
       
        if(conexion != null){
            System.out.println("conexion exitosa");
            
        }
            
        
        }catch(SQLException ex){
            System.out.println("ERROR : "+ex.getMessage());
            System.out.println("no se pude conetar a la base de datos :");
        }
        return null;
   
    
    }
    
   

}
