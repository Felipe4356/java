/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;
import vistas.menu_inicio_p;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author droid
 */
public class usuario {
    
    private int id;
    private String nombre;
    private String contraseña;

    public usuario(int id, String nombre, String contraseña) {
        this.id = id;
        this.nombre = nombre;
        this.contraseña = contraseña;
    }

    public usuario() {
    }

    // Getters y setters (métodos para acceder y modificar los atributos)

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

public boolean login(String username, String password) {
    String Url = "jdbc:mysql://localhost:3306/MovieBD";
    String User = "root";
    String Password = "Felipe432156";

    try (Connection connection = DriverManager.getConnection(Url, User, Password)) {
        String query = "SELECT * FROM usuario WHERE LOWER(nombre) = LOWER(?) AND contraseña = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, username.toLowerCase());

            preparedStatement.setString(2, password);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    
                    JOptionPane.showMessageDialog(null, "se encontró el usuario");
                    System.out.println("Inicio de sesión exitoso para el usuario: " + username);
                    
                    menu_inicio_p men=new menu_inicio_p();
                    men.setVisible(true);// 
                    
                    return true; // 
                } else {
                    
                    JOptionPane.showMessageDialog(null, "el usuario no se encuentra");
                    System.out.println("Usuario o contraseña incorrectos para: " + username);
                    return false; 
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        Logger.getLogger(usuario.class.getName()).log(Level.SEVERE, null, e);
    }

    return false;
}
}

