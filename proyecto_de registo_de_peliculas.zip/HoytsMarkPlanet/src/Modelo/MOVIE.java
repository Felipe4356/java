/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import controlador.BD;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author droid
 */
public class MOVIE {

    BD conectar = new BD();

    private int id;
    private String titulo;
    private String director;
    private int anno;
    private int duracion;
    private String genero;

    public MOVIE(int id, String titulo, String director, int anno, int duracion, String genero) {
        this.id = id;
        this.titulo = titulo;
        this.director = director;
        this.anno = anno;
        this.duracion = duracion;
        this.genero = genero;
    }

    public MOVIE() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public int getAnno() {
        return anno;
    }

     public void setAnno(int anno) {
        this.anno = anno;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
//para insertar datos 
    public void insertarPelicula(JTextField paramTitulo, JTextField paramNombreDirector, JTextField paramAnno, JTextField paramDuracion, JTextField parmGenero,JComboBox jComboBoxgenero) throws SQLException {
        String titulo = paramTitulo.getText();
        String director = paramNombreDirector.getText();
        String annoStr = paramAnno.getText();
        String duracionStr = paramDuracion.getText();
        
        String generoItem=(String) jComboBoxgenero.getSelectedItem();
        // condicion para Validar que no haya campos vacíos
        if (titulo.isEmpty() || director.isEmpty() || annoStr.isEmpty() || duracionStr.isEmpty()){
            System.out.println("Por favor, complete todos los campos.");
            JOptionPane.showMessageDialog(null, "porfavor complete todos los campos", "advertencia", JOptionPane.PLAIN_MESSAGE);
            return;
        }

//para validar numeros y no letra
        int anno, duracion;
        try {
            anno = Integer.parseInt(annoStr);
            duracion = Integer.parseInt(duracionStr);
        } catch (NumberFormatException e) {
            System.out.println("Ingrese valores numéricos válidos para Año y Duración.");
            JOptionPane.showMessageDialog(parmGenero, "ingrese numeros validos para año y duracion");
            return;
        }
         
            
        
        
        String url = "jdbc:mysql://localhost:3306/movieBD";
        String usuario = "root";
        String contraseña = "Felipe432156";
        conectar.conexionBD();

        try (Connection conexion = DriverManager.getConnection(url, usuario, contraseña)) {
            String consulta = "INSERT INTO MOVIE (titulo, director, anno, duracion, genero) VALUES (?, ?, ?, ?, ?)";
            try(PreparedStatement pstmt = conexion.prepareStatement(consulta)) {
                pstmt.setString(1, titulo);
                pstmt.setString(2, director);
                pstmt.setInt(3, anno);
                pstmt.setInt(4, duracion);
                pstmt.setString(5, generoItem);

                pstmt.executeUpdate();
                System.out.println("Película insertada correctamente.");
                 JOptionPane.showMessageDialog(null, "Película insertada correctamente.", "mensaje", JOptionPane.PLAIN_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
//para poder ver  los datos en el metodo listar
    public void mostrarDatosEnTabla(JTable lista_tabla) {
        DefaultTableModel modelo = new DefaultTableModel();

        modelo.addColumn("ID");
        modelo.addColumn("titulo");
        modelo.addColumn("director");
        modelo.addColumn("año");
        modelo.addColumn("duracion (min)");
        modelo.addColumn("genero");

        String url = "jdbc:mysql://localhost:3306/MovieBD";
        String usuario = "root";
        String contraseña = "Felipe432156";

        try (Connection conexion = DriverManager.getConnection(url, usuario, contraseña)) {
            String query = "SELECT * FROM movie";
            try (PreparedStatement pstmt = conexion.prepareStatement(query)) {
                var rs = pstmt.executeQuery();

                while (rs.next()) {
                    Object[] fila = new Object[6];  
                    fila[0] = rs.getInt("id");
                    fila[1] = rs.getString("titulo");
                    fila[2] = rs.getString("director");
                    fila[3] = rs.getInt("anno");
                    fila[4] = rs.getInt("duracion");
                    fila[5] = rs.getString("genero");  

                    modelo.addRow(fila);
                }

                lista_tabla.setModel(modelo); 

                rs.close();
            }
        } catch (SQLException e) {
            System.out.println("Error al mostrar datos en la tabla: " + e.getMessage());
        }
    }
//filtro que solo muestra el tipo de genero  de pelicula selecionado para mostrar en un table
    public void filtro_genero(JTable lista_tabla, JComboBox<String> generoComboBox) {
    DefaultTableModel modelo = new DefaultTableModel();

    modelo.addColumn("ID");
    modelo.addColumn("titulo");
    modelo.addColumn("director");
    modelo.addColumn("año");
    modelo.addColumn("duracion(min)");
    modelo.addColumn("genero");

    String url = "jdbc:mysql://localhost:3306/movieBD";
    String usuario = "root";
    String contraseña = "Felipe432156";

    try (Connection conexion = DriverManager.getConnection(url, usuario, contraseña)) {
        String generoSeleccionado = generoComboBox.getSelectedItem().toString();
        String query;

        if (generoSeleccionado.isEmpty()) {
            // Sin filtro, mostrar todas las películas
            query = "SELECT * FROM movie";
        } else {
            // Filtrar por género seleccionado
            query = "SELECT * FROM movie WHERE genero=?";
        }

        try (PreparedStatement pstmt = conexion.prepareStatement(query)) {
            if (!generoSeleccionado.isEmpty()) {
                pstmt.setString(1, generoSeleccionado);
            }

            try (var rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Object[] fila = new Object[6];
                    fila[0] = rs.getInt("id");
                    fila[1] = rs.getString("titulo");
                    fila[2] = rs.getString("director");
                    fila[3] = rs.getInt("anno");
                    fila[4] = rs.getInt("duracion");
                    fila[5] = rs.getString("genero");

                    modelo.addRow(fila);
                }
            }
        }
    } catch (SQLException e) {
        System.out.println("Error al mostrar datos en la tabla: " + e.getMessage());
    }

    lista_tabla.setModel(modelo);
}
//filtro año que solo muestra las pelicula que esten en el rango selecionado 
                
      public void filtrar_Anios(JTable lista_tabla, JTextField textFieldInicio, JTextField textFieldFin) {
    DefaultTableModel modelo = new DefaultTableModel();

    modelo.addColumn("ID");
    modelo.addColumn("titulo");
    modelo.addColumn("director");
    modelo.addColumn("año");
    modelo.addColumn("duracion(min)");
    modelo.addColumn("genero");

    String url = "jdbc:mysql://localhost:3306/movieBD";
    String usuario = "root";
    String contraseña = "Felipe432156";

    try (Connection conexion = DriverManager.getConnection(url, usuario, contraseña)) {
        String query = "SELECT * FROM movie WHERE anno BETWEEN ? AND ?";
        try (PreparedStatement pstmt = conexion.prepareStatement(query)) {
            // Obtener los límites del rango de años desde los JTextField
            int inicio = Integer.parseInt(textFieldInicio.getText());
            int fin = Integer.parseInt(textFieldFin.getText()); // 

            // se establece los límites del rango de años 
            pstmt.setInt(1, inicio);
            pstmt.setInt(2, fin);

            try (var rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Object[] fila = new Object[6];
                    fila[0] = rs.getInt("id");
                    fila[1] = rs.getString("titulo");
                    fila[2] = rs.getString("director");
                    fila[3] = rs.getInt("anno");
                    fila[4] = rs.getInt("duracion");
                    fila[5] = rs.getString("genero");

                    modelo.addRow(fila);
                }
            }
        }
    } catch (SQLException | NumberFormatException e) {
        System.out.println("Error al mostrar datos en la tabla: ");
       JOptionPane.showMessageDialog(null, "ingrese el rango del año quiere ingresar porfavor");
    
    }
    

    lista_tabla.setModel(modelo);
}

                
    public void EliminarProducto(int id) {
    String url = "jdbc:mysql://localhost:3306/movieBD";
    String usuario = "root";
    String contraseña = "Felipe432156";

    try (Connection conexion = DriverManager.getConnection(url, usuario, contraseña)) {
        String query = "DELETE FROM movie WHERE id= ?";
        try (PreparedStatement pstmt = conexion.prepareStatement(query)) {
            pstmt.setInt(1, id);

            int filasEliminadas = pstmt.executeUpdate();
            if (filasEliminadas > 0) {
                System.out.println("Película eliminada correctamente.");
                JOptionPane.showMessageDialog(null, "Película eliminada correctamente.", "Mensaje", JOptionPane.PLAIN_MESSAGE);
            } else {
                System.out.println("No se encontró la película con ID: " + id);
                JOptionPane.showMessageDialog(null, "No se encontró la película con ID: " + id, "Mensaje", JOptionPane.PLAIN_MESSAGE);
            }
        }
    } catch (SQLException e) {
        System.out.println("Error al eliminar la película: ");
        JOptionPane.showMessageDialog(null, "Error al eliminar la película: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}




    public void actualizarPelicula(JTextField parmid, JTextField paramTitulo, JTextField paramNombreDirector, JTextField paramAnno, JTextField paramDuracion, JTextField parmGenero,JComboBox jComboBoxgenero) {
    String url = "jdbc:mysql://localhost:3306/movieBD";
    String usuario = "root";
    String contraseña = "Felipe432156";
    String titulo = paramTitulo.getText();
    String director = paramNombreDirector.getText();
    String annoStr = paramAnno.getText();
    String duracionStr = paramDuracion.getText();
     String generoItem=(String) jComboBoxgenero.getSelectedItem();
    String id = parmid.getText();
if (titulo.isEmpty() || director.isEmpty() || annoStr.isEmpty() || duracionStr.isEmpty() ) {
            System.out.println("Por favor, complete todos los campos.");
            JOptionPane.showMessageDialog(null, "porfavor complete todos los campos", "advertencia", JOptionPane.PLAIN_MESSAGE);
            return;
        }

int anno, duracion;
        try {
            anno = Integer.parseInt(annoStr);
            duracion = Integer.parseInt(duracionStr);
        } catch (NumberFormatException e) {
            System.out.println("Ingrese valores numéricos válidos para Año y Duración.");
            JOptionPane.showMessageDialog(parmGenero, "ingrese numeros validos para año y duracion");
            return;
        }
         
//
    try (Connection conexion = DriverManager.getConnection(url, usuario, contraseña)) {
        String query = "UPDATE MOVIE SET titulo=?, director=?, anno=?, duracion=?, genero=? WHERE id=?";
        try (PreparedStatement pstmt = conexion.prepareStatement(query)) {
            pstmt.setString(1, titulo);
            pstmt.setString(2, director);
            try{
            pstmt.setInt(3, Integer.parseInt(annoStr));
            pstmt.setInt(4, Integer.parseInt(duracionStr));
            }catch(NumberFormatException e){
                System.out.println(""); 
                JOptionPane.showMessageDialog(null, "ingrese numeros valido en año y duracion");
                       
                        ;}
            pstmt.setString(5, generoItem);
            pstmt.setInt(6, Integer.parseInt(id));  // Establecer el valor para el id

            pstmt.executeUpdate();
            System.out.println("Película modificada correctamente.");
            JOptionPane.showMessageDialog(null,"pelicula modificada correctamente");
            
        }
    } catch (SQLException | NumberFormatException e) {
        e.printStackTrace();
        System.out.println("Error al actualizar la película: ");
        
    
    
    }
   }
     
    public void buscarPelicula(int id) {
    if (id > 0) {
        try (Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/movieBD", "root", "Felipe432156")) {
            String query = "SELECT * FROM MOVIE WHERE id=?";
            try (PreparedStatement pstmt = conexion.prepareStatement(query)) {
                pstmt.setInt(1, id);

                
                
                
                try (var rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        System.out.println("Película encontrada");
                        
                        // Muestra la ventana de diálogo de confirmación para poder eliminar o no
                        int confirmacion = JOptionPane.showConfirmDialog(null, "¿Deseas eliminar esta película?", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
                        
                        if (confirmacion == JOptionPane.YES_OPTION) {
                            // Llama al método para eliminar la película
                            EliminarProducto(id);
                        } else {
                            System.out.println("Eliminación cancelada.");
                        }
                        
                    } else {
                        System.out.println("No se encontró ninguna película con ese ID");
                        JOptionPane.showMessageDialog(null, "No se encontró ninguna película con ese ID.", "Mensaje", JOptionPane.PLAIN_MESSAGE);
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error al buscar la película: " + ex.getMessage());
        }
    } else {
        System.out.println("Por favor, ingrese un ID válido");
        JOptionPane.showMessageDialog(null, "Por favor, ingrese un ID válido.", "Mensaje", JOptionPane.PLAIN_MESSAGE);
    }
}


public void buscardatosPeliculas(int id, JTextField textFieldTitulo, JTextField textFieldDirector, JTextField textFieldAnno, JTextField textFieldDuracion) {
    if (id > 0) {
        try (Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/movieBD", "root", "Felipe432156")) {
            String query = "SELECT * FROM MOVIE WHERE id=?";
            try (PreparedStatement pstmt = conexion.prepareStatement(query)) {
                pstmt.setInt(1, id);

                try (var rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        // al encontrar la pelicula muestra la información en los JTextField
                        textFieldTitulo.setText(rs.getString("titulo"));
                        textFieldDirector.setText(rs.getString("director"));
                        textFieldAnno.setText(String.valueOf(rs.getInt("anno")));
                        textFieldDuracion.setText(String.valueOf(rs.getInt("duracion")));
                        

                     

                    } else {
                        System.out.println("No se encontró ninguna película con ese ID");
                        JOptionPane.showMessageDialog(null, "No se encontró ninguna película con ese ID.", "Mensaje", JOptionPane.PLAIN_MESSAGE);
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error al buscar la película: " + ex.getMessage());
        }
    } else {
        System.out.println("Por favor, ingrese un ID válido");
        JOptionPane.showMessageDialog(null, "Por favor, ingrese un ID válido.", "Mensaje", JOptionPane.PLAIN_MESSAGE);
    }
}






}

                
            

        
    

